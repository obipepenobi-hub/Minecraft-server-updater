scoreboard players set #schritte bong.ray 0
execute anchored eyes positioned ^ ^ ^ run function bong:strahl
