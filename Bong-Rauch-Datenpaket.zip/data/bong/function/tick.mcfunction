execute as @e[type=minecraft:marker,tag=bong.stand] at @s unless block ~ ~ ~ minecraft:brewing_stand run kill @s
execute as @e[type=minecraft:marker,tag=bong.stand] at @s run function bong:rauch
execute as @e[type=minecraft:item_display,tag=bong.koch] at @s unless block ~ ~-0.5 ~ minecraft:brewing_stand run kill @s
