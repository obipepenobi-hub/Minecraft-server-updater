execute if block ~ ~ ~ minecraft:brewing_stand align xyz positioned ~0.5 ~ ~0.5 unless entity @e[type=minecraft:marker,tag=bong.stand,distance=..0.5] run summon minecraft:marker ~ ~ ~ {Tags:["bong.stand"]}
execute if block ~ ~ ~ minecraft:brewing_stand run return 0
scoreboard players add #schritte bong.ray 1
execute if score #schritte bong.ray matches ..70 positioned ^ ^ ^0.1 run function bong:strahl
