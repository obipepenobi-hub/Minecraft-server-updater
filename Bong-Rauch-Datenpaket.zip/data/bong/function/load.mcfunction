scoreboard objectives add bong.ray dummy
