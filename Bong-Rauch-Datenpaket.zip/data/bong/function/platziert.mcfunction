advancement revoke @s only bong:platziert
function bong:hier
