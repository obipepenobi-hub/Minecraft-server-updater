# Kochen: Blubber-Animation (Item-Display mit animiertem Modell)
execute if data block ~ ~ ~ {BrewTime:0s} run kill @e[type=minecraft:item_display,tag=bong.koch,distance=..0.6]
execute unless data block ~ ~ ~ {BrewTime:0s} unless entity @e[type=minecraft:item_display,tag=bong.koch,distance=..0.6] run summon minecraft:item_display ~ ~0.5 ~ {Tags:["bong.koch"],item_display:"none",item:{id:"minecraft:glass_bottle",count:1,components:{"minecraft:item_model":"bong:kochen"}}}
# Leerlauf: ab und zu ein Woelkchen aus dem Mundstueck
execute if data block ~ ~ ~ {BrewTime:0s} if predicate bong:selten run particle minecraft:white_smoke ~ ~1.02 ~ 0.02 0.02 0.02 0.003 1
execute if data block ~ ~ ~ {BrewTime:0s} run return 0
# Beim Brauen: Rauch aus dem Mundstueck, der Kopf kokelt
execute if predicate bong:oft run particle minecraft:white_smoke ~ ~1.02 ~ 0.03 0.06 0.03 0.01 2
execute if predicate bong:manchmal run particle minecraft:smoke ~-0.44 ~0.8 ~ 0.03 0.02 0.03 0.005 1
